# Nest (Sai, Jane, Qinmeng, Yulan)


## Status

The team has developed preliminary competitor research, a loyalty-program concept and proposed app screens. They were not progressive enough in the wake of a silence from the Sponsor for 2 weeks. Communication has resumed, meetings with CEO and Marketing Exec is this week.


## Areas of Focus/Concern


- The underlying business problem remains unvalidated. The team was focused on developing loyalty features before establishing the root cause of operational efficiency. This was raised with them on October 8.

- They have moved to a more hypothesis driven analysis with some competitor research over the last week but it has slowed.

- I have attempted to steer their analysis to quantify building a new app vs configuring an existing solution.

- There is ambiguity between loyalty and developing a sustainability program for Nest – the team have not asserted what the limits of the deliverable will be to the sponsor

- Heavy reliance on data from the customer which appears to be minimal and fragmented. The team have not established what they will use the data for

## Summary

The Nest team has made progress in their research approach, but their lack of documentation makes it difficult to gauge how robust their plan really is. They are yet to determine what the driver of the loyalty program request is, and this week’s meeting with the CEO is an opportunity for them to get an accurate read.
