# Taulia (Zonghui, Jiaqi, Xinran, He)


## Status

Last activity – met with sponsor on October 13 and submitted questions for the SAP team. Their latest check-in document proposes a research-only project examining an AI hybrid system for payment-term renegotiation.


## Areas of Focus/Concern


- None of the research/illustrations maps back to actual research performed on the organization. They have a lot 0f AI-generated long form speak that describes concepts but appears irrelevant.

- The teams communication style with the sponsor is a flag. Lengthy email content and extensive requests to the sponsor does not establish confidence.

- This team has little to no communication in the Spaces channel and their project plan and risk tracker is lapse.

## Summary

Lots of content churned out, but I have limited confidence that any of it is meaningful. Deliverable accountability is an issue with this team. Their plan is based on general research, but they have no way to apply it to the problem.
