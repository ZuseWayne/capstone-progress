# Tripod (Pooja, Linda, Yuhe, Xinyi)


## Status

The team has been granted reference materials for Tripod training. developed interview questions and a questionnaire, and have three stakeholder interviews this week

## Areas of Focus/Concern


- The business problem and priority user need remain unvalidated. Several AI use cases are being considered, but the team has not yet established which investigation task requires intervention, why existing tools are insufficient, or what improvement they will demonstrate – I expected the interviews to be built around these problems but it focuses on asking respondents about their sentiment on specific AI solutions.

- They developed a “pain score”

  “Pain score = effort % × the average of difficulty and rework, averaged across the three interviewees.”

  This does not have a source citation as to why this is applicable, but it subjectively quantifies sentiment, which is a risky route to base recommendations/solutions on.

- The team has not yet validated where AI introduction is valuable or feasible

## Summary

The Tripod team has shown significant intiative in arranging interviews but I find no larger plan with how they intend to use the data. The interview sample is tiny (n=3), and it appears to be the only data they intend to use to inform their solution, I could not find evidence of industry and market research. This is symptomatic of no updates in their Risk tracker since Sep 26th.
