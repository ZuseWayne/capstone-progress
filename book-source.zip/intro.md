# Capstone Team Progress Summary

**October 18, 2026**  
Prepared by Wayne Singh for Prof. Thomas Mazzone

## Team assessments

- [IN-18 — Shruti, Aatish, Pooja, Nancy](in-18.md)
- [Tripod — Pooja, Linda, Yuhe, Xinyi](tripod.md)
- [Nest — Sai, Jane, Qinmeng, Yulan](nest.md)
- [Taulia — Zonghui, Jiaqi, Xinran, He](taulia.md)

Each chapter contains the team's status, areas of focus/concern, and summary.

[Download the original document](original.txt)
